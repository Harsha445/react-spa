const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-react");
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');

module.exports = (webpackConfigEnv) => {
  const defaultConfig = singleSpaDefaults({
    orgName: "api",
    projectName: "api",
    webpackConfigEnv
  });

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    externals: [/^rxjs\/?.*$/],
    plugins: [
      new ModuleFederationPlugin({
        name: "api",
        library: { type: 'system' },
        filename: "remoteEntry.js",
        exposes: {
          "./api-api": "./src/api-api.js",
        },
        shared: ['react', 'react-dom'] // { '@fluentui/react': { singleton: true, eager: true } }
      })
    ]
  });
};



