
class AppData {
   constructor(){
    this.project = [
        {
            id:"p1",
            name:"Banking"
        },
        {
            id:"p2",
            name:"Retail"
        },
        {
            id:"p3",
            name:"Health care"
        }
    ]
}

getName(){
    return this._name;
}

setName(value) {
    this.name= value;
}

setProject (value) {
    this.project = value;
}

setBackEndDat(){
    
}

}

export const appData = new AppData();
 