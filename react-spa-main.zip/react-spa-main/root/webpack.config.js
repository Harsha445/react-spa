const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-ts");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');

module.exports = (webpackConfigEnv, argv) => {
  const orgName = "root";
  const defaultConfig = singleSpaDefaults({
    orgName,
    projectName: "root-config",
    webpackConfigEnv,
    argv,
    disableHtmlGeneration: true
  });

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    plugins: [
      new HtmlWebpackPlugin({
        inject: false,
        template: "src/index.ejs",
        templateParameters: {
          isLocal: webpackConfigEnv && webpackConfigEnv.isLocal,
          orgName
        }
      }),
      new ModuleFederationPlugin({
        name: "nga-root-config",
        remotes: {
          "api": "api@http://localhost:8083/remoteEntry.js",
          "style-guide": "style-guide@http://localhost:8084/styleComponents.js",
        },
        shared: ['react', 'react-dom'] //, { '@fluentui/react': { singleton: true, eager: true } }
      })

    ]
  });
};
